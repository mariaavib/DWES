<?php
    /*Local*/
    $servidor = 'localhost';
    $usuario = 'root';
    $contraseña = '';
    $basedatos = 'pruebas';
?>